{
    'name': 'Reparaciones Encargadas',
    'description': 'Aqui estan las reparaciones que tiene cada empleado',
    'author': 'Xavi Sbert',
    'depends': ['repair', 'hr'],
    'application': True,
    'data' : ['re_se7.xml']
}
