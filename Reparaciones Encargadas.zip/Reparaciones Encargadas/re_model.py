#-*- coding: utf-8 -*-
from openerp import models, fields

class ReSe7(models.Model):
    _name = 're.se7'
    name = fields.Char('Description', required=True)
    is_done = fields.Boolean('Done?')
    active = fields.Boolean('Active?', default=True)
